### 0.1.1
* Support of absolute URLs (#10).
* Fixed the CORS issue (#11).
* Fixed the destroy method.
* Fixed parsing of empty options.
* Poster and video positions are the same now.
* Syntax and behavior of the position option are similar to the CSS `background-position` property.
* Add support of the `.jpeg` extension.
